
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager 

import redis
import time

r = redis.Redis(host='redis', port=6379, db=0, decode_responses=True)


def crawl(url):
    
    print(url, flush=True)

    options = webdriver.ChromeOptions()
    options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--js-flags=--noexpose_wasm")

    driver = webdriver.Chrome(options=options)
    driver.get(url)
    time.sleep(60)
    driver.quit()



def process_queue():
    while True:
        try:
            result = r.lpop('url')
            if not result:
                print("No URL found, waiting...", flush=True)
                time.sleep(1)
                continue

            crawl(result)

        except Exception as e:
            print(f"error: {e}", flush=True)
            time.sleep(1)

if __name__ == "__main__":
    print("bot started", flush=True)
    process_queue()
