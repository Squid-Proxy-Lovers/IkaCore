from flask import Flask, request, jsonify, render_template, session, redirect
import mysql.connector
import os
from urllib.parse import urlparse
import secrets
import redis
import bcrypt

app = Flask(__name__)

# Session configuration
app.config['SECRET_KEY'] = secrets.token_hex(32)

DB_CONFIG = {
    'host': os.getenv('DB_HOST'),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME')
}

def init_db():
    flag = os.getenv('FLAG')

    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()

    cursor.execute('DROP TABLE IF EXISTS histories')
    cursor.execute('DROP TABLE IF EXISTS notes')
    cursor.execute('DROP TABLE IF EXISTS note_user')
    conn.commit()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS histories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            url TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            content TEXT NOT NULL COLLATE utf8mb4_bin,
            user_id INT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS note_user (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL
        )
    ''')
    
    cursor.execute('INSERT INTO notes(title, content) values(%s,%s)', ('flag', flag))

    conn.commit()
    conn.close()

def login_required():
    return 'user_id' in session

@app.route('/register', methods=['GET'])
def register_page():
    if 'user_id' in session:
        return redirect('/notes')
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    
    cursor.execute('SELECT id FROM note_user WHERE username = %s', (username,))
    if cursor.fetchone():
        conn.close()
        return 'Username already exists'
    
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    cursor.execute('INSERT INTO note_user (username, password) VALUES (%s, %s)', (username, hashed_password))
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()
    
    return redirect('/login')


@app.route('/')
def index():
    if 'user_id' in session:
        return redirect('/notes')
    return redirect('/login')

@app.route('/login', methods=['GET'])
def login_page():
    if 'user_id' in session:
        return redirect('/notes')
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form.get('username')
    password = request.form.get('password')
    
    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    
    cursor.execute('SELECT id, username, password FROM note_user WHERE username = %s', (username,))
    user = cursor.fetchone()
    conn.close()

    if not user or not bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):
        return redirect('/login')

    session.clear()    
    session['user_id'] = user[0]
    session['username'] = user[1]
    
    return redirect('/notes')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

@app.route('/notes/add', methods=['GET'])
def new_note():
    if not login_required():
        return redirect('/login')
    return render_template('add_note.html')

@app.route('/notes/add', methods=['POST'])
def create_note():
    if not login_required():
        return jsonify({'error': 'Authentication required'}), 401
    
    title = request.form.get('title')
    content = request.form.get('content')

    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute('INSERT INTO notes (title, content, user_id) VALUES (%s, %s, %s)', (title, content, session['user_id']))
    conn.commit()

    conn.close()
    
    return redirect('/notes')


@app.route('/notes', methods=['GET'])
def get_notes():
    if 'user_id' not in session:
        return redirect('/login')

    user_id = session['user_id']
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute('SELECT id, title, created_at FROM notes WHERE user_id = %s ORDER BY created_at DESC', (user_id,))
    notes = cursor.fetchall()
    conn.close()
    
    notes_list = []
    for note in notes:
        notes_list.append({
            'id': note[0],
            'title': note[1],
            'created_at': note[2].isoformat() if note[2] else None
        })

    print(notes)

    return render_template('notes.html', username=session['username'], notes=notes_list)

@app.route('/notes/<int:note_id>', methods=['GET'])
def get_note(note_id):
    if not login_required():
        return redirect('/login')
    
    user_id = session['user_id']
    
    conn = mysql.connector.connect(**DB_CONFIG)
    cursor = conn.cursor()
    cursor.execute('SELECT id, title, content, created_at FROM notes WHERE id = %s AND user_id = %s', (note_id, user_id))
    note = cursor.fetchone()
    conn.close()
    
    if not note:
        return redirect('/notes')
     
    return render_template('note.html', note={
        'id': note[0],
        'title': note[1],
        'content': note[2],
        'created_at': note[3].isoformat() if note[3] else None
    })


@app.route('/inquiry', methods=['GET'])
def inquiry_page():
    return render_template('inquiry.html')

@app.route('/inquiry', methods=['POST'])
def inquiry():
    url = request.form.get('url')
    if not url:
        return render_template('inquiry.html', message='Thank you for your inquiry! ')

    try:
        parsed = urlparse(url)
    except Exception:
        return render_template('inquiry.html', error='Invalid URL format.'), 400

    if not parsed.scheme in ('http', 'https'):
        return render_template('inquiry.html', error='URL scheme must be http or https.'), 400

    redis_client = redis.Redis(host='redis', port=6379, db=0)

    redis_client.lpush('url', url)

    return render_template('inquiry.html', message='Thank you for your inquiry! We will check the URL soon.')


if __name__ == '__main__':
    init_db()
    app.run(debug=False, host='0.0.0.0', port=1337)
