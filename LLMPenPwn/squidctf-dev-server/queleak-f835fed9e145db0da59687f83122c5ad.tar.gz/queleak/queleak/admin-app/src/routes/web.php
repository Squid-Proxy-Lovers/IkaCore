<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminNoteController;

Route::any('/admin/notes', [\App\Http\Controllers\AdminNoteController::class, 'show'])->name('admin.notes.show');