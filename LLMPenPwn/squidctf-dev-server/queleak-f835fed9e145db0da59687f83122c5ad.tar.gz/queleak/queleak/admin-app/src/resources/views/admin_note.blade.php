<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title">
                            <i class="material-icons left">note</i>
                            {{ __('Notes') }}
                        </span>
                        
                        <div class="row">
                            <form method="POST" action="{{ url()->current() }}">
                                @csrf
                                <div class="input-field col s10">
                                    <i class="material-icons prefix">search</i>
                                    <input id="keyword" name="keyword" type="text" value="">
                                    <label for="keyword">title Search</label>
                                </div>
                                <div class="col s2">
                                    <button class="btn waves-effect waves-light" type="submit" style="margin-top: 25px;">
                                        Search
                                        <i class="material-icons right">send</i>
                                    </button>
                                </div>
                            </form>
                        </div>
                        
                        @if($notes->count() > 0)
                            <table class="striped responsive-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>User ID</th>
                                        <th>Title</th>
                                        <th>Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($notes as $note)
                                        <tr>
                                            <td>{{ $note->id }}</td>
                                            <td>{{ $note->user_id }}</td>
                                            <td class="truncate">{{ $note->title }}</td>
                                            <td>{{ $note->created_at->format('Y-m-d H:i:s') }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        @else
                            <div class="center-align">
                                <i class="material-icons medium grey-text">inbox</i>
                                <p class="grey-text">No notes found.</p>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
