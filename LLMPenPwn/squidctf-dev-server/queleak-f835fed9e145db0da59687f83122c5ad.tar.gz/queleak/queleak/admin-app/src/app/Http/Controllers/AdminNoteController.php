<?php


namespace App\Http\Controllers;

use App\Models\Note;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class AdminNoteController extends Controller
{

    public function show(Request $request)
    {

        $keyword = $request->input('keyword');
        if ($keyword) {
            $notes = Note::whereRaw("title LIKE '%" . $keyword . "%'")
                ->orderBy('created_at', 'desc')
                ->limit(10)->get();
        } else {
            $notes =    Note::limit(10)
                ->orderBy('created_at', 'desc')
                ->limit(10)->get();
        }

        return view("admin_note", [
            'notes' => $notes,
            'keyword' => $keyword
        ]);
    }


}

