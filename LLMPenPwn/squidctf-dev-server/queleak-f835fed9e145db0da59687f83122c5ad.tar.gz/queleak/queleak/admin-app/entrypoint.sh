#!/bin/bash

until mysql -h"$DB_HOST" -u"$DB_USERNAME" -p"$DB_PASSWORD" -e 'SELECT 1'; do
  echo "Waiting for MySQL to be ready..."
  sleep 2
done

php artisan optimize
php artisan migrate --force
/opt/bitnami/scripts/laravel/run.sh
